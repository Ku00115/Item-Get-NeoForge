---
name: item-get-config-author
description: Generate, edit, validate, and explain Item Get! reminder configuration files for Minecraft modpacks. Use when Codex needs to create or modify config/item_get/rules.json, add Item Get! reminders from pack-author notes, write manual/API-triggered entries, convert tutorial text into rules, choose trigger types, keep rule ids stable, prepare translation-key-friendly title/subtitle/description fields, or produce commands/API examples for Item Get! external triggers.
---

# Item Get Config Author

## Overview

Use this skill to author Item Get! reminder rules directly in `config/item_get/rules.json` for pack authors. Prefer editing the config file when the user wants many reminders, repeatable setup, generated tutorial entries, or AI-assisted copywriting instead of clicking through the in-game editor.

## Workflow

1. Locate the active Item Get! config:
   - Preferred: `<instance>/config/item_get/rules.json`
   - If missing, create it as a JSON array.
   - Do not edit per-world progress data for rule authoring.
2. Read the existing rules before editing.
3. Preserve existing `id` values unless the user asks to rename an entry.
4. Generate new ids in lowercase snake case, stable and descriptive, such as `modpack_first_magic_terminal`.
5. Use translation keys when the user is preparing a localized modpack; otherwise plain text is acceptable.
6. Increment `triggerRevision` only when an existing rule's trigger conditions change in a way that should allow players to see it again.
7. Validate and format the file with `scripts/validate_rules.py`.

## Rule Shape

For full field notes and examples, read `references/rule-schema.md` when creating or editing rules.

Minimum rule:

```json
{
  "id": "modpack_first_magic_terminal",
  "triggerType": "MANUAL",
  "trigger": {
    "manual": "modpack:first_magic_terminal"
  },
  "title": "item_get.modpack.magic_terminal.title",
  "subtitle": "item_get.modpack.magic_terminal.subtitle",
  "description": "item_get.modpack.magic_terminal.description",
  "icon": "minecraft:writable_book",
  "displayStyle": "HORIZONTAL",
  "sound": "item_get:item_acquired_mystic",
  "pauseSingleplayer": true,
  "enabled": true,
  "triggerRevision": 1
}
```

## Trigger Guidance

- Use `ITEM_ACQUIRED` for real item acquisition milestones.
- Use `MANUAL` for scene blocks, command blocks, scripted interactions, quests, NPC dialogue callbacks, or other events outside Item Get!'s automatic detectors.
- Use `OBSERVE_BLOCK`, `OBSERVE_ENTITY`, or `HOVER_ITEM` for FTB-Quest-style learning prompts.
- Use `ADVANCEMENT_DONE`, `DEATH_BY`, `DIMENSION_CHANGED`, biome, structure, weather, time, health, hunger, and effect triggers when the condition already exists in Item Get!.
- Use multiple conditions only when the pack author explicitly needs AND/OR logic. Keep the default to one condition.

For external/manual entries, provide at least one usage example after editing:

```mcfunction
itemget fire @p modpack:first_magic_terminal
```

or Java:

```java
ItemGetApi.fireExternalTrigger(player, "modpack:first_magic_terminal");
```

## Copywriting Rules

- Keep titles short and memorable.
- Put the actual trigger context in `subtitle` only when the author did not write a custom subtitle.
- Keep descriptions useful enough for the handbook; side toasts should still link to readable detail.
- Use `\n` inside JSON strings for line breaks when the user asks for multi-paragraph description text.
- Do not bake formatting into images. Use text fields for title/subtitle/description.

## Validation

Run:

```powershell
python "<skill-dir>/scripts/validate_rules.py" "<instance>/config/item_get/rules.json" --write
```

The script checks duplicate ids, required fields, known trigger types, common missing trigger keys, and JSON formatting. If validation reports warnings, explain them and fix the file when the intent is clear.
