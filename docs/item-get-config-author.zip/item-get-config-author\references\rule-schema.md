# Item Get! Rule Schema

## Storage

Rules live in:

```text
config/item_get/rules.json
```

The file is a JSON array of rule objects.

## Core Fields

- `id`: stable unique rule id. Use lowercase snake case.
- `triggerType`: legacy primary trigger type. Match the first condition.
- `trigger`: trigger data object. For multiple conditions, it also contains `conditions` and `condition_logic`.
- `title`: plain text or translation key.
- `subtitle`: plain text or translation key. Empty is allowed; the mod can show a trigger summary.
- `description`: plain text or translation key. Use `\n` for line breaks in JSON.
- `icon`: item id used as fallback icon.
- `iconImage`: optional image name from `config/item_get/images`.
- `iconStack`: optional serialized stack for NBT-sensitive icons such as potions.
- `ponderTarget`: optional linked Ponder/Create Ponder/Ponderer target id.
- `displayStyle`: `HORIZONTAL` for full popup or `SIDE` for side toast.
- `sound`: sound id, such as `item_get:item_acquired`, `item_get:item_acquired_mystic`, or a custom sound id.
- `pauseSingleplayer`: whether full popup pauses singleplayer.
- `enabled`: whether the rule is active.
- `triggerRevision`: integer revision used for player progress. Increase when an edited trigger should be available again.

## Trigger Data Keys

- `ITEM_ACQUIRED`: `item`, optional `count`, optional `nbt`, optional `stack`
- `ENTITY_KILLED`: `entity`, optional `count`
- `HEALTH_AT`: `value`
- `HUNGER_AT`: `value`
- `EFFECT_GAINED`: `effect`
- `WEATHER_IS`: `weather` with `clear`, `rain`, or `thunder`
- `TIME_IS`: `time` with `day`, `noon`, `night`, or `midnight`
- `ENTER_BIOME`: `biome`
- `ENTER_STRUCTURE`: `structure`
- `DIMENSION_CHANGED`: `dimension`
- `DEATH_BY`: `death`
- `ADVANCEMENT_DONE`: `advancement`
- `OBSERVE_BLOCK`: `block`, optional `count` in ticks
- `OBSERVE_ENTITY`: `entity`, optional `count` in ticks
- `HOVER_ITEM`: `item`, optional `count` in ticks, optional `nbt`, optional `stack`
- `MANUAL`: `manual`

## Multiple Conditions

Use `trigger.conditions`:

```json
{
  "conditions": [
    {
      "type": "MANUAL",
      "data": {
        "manual": "modpack:first_magic_terminal"
      }
    },
    {
      "type": "DIMENSION_CHANGED",
      "data": {
        "dimension": "minecraft:the_nether"
      }
    }
  ],
  "condition_logic": "AND",
  "manual": "modpack:first_magic_terminal"
}
```

Rules:

- `condition_logic` is `AND` or `OR`.
- Keep the first condition mirrored into the legacy top-level trigger fields.
- Do not use reverse/NOT unless a future mod version explicitly supports it again.

## Examples

Manual scene entry:

```json
{
  "id": "modpack_first_terminal",
  "triggerType": "MANUAL",
  "trigger": {
    "manual": "modpack:first_terminal"
  },
  "title": "item_get.modpack.first_terminal.title",
  "subtitle": "item_get.modpack.first_terminal.subtitle",
  "description": "item_get.modpack.first_terminal.description",
  "icon": "minecraft:writable_book",
  "displayStyle": "HORIZONTAL",
  "sound": "item_get:item_acquired_mystic",
  "pauseSingleplayer": true,
  "enabled": true,
  "triggerRevision": 1
}
```

Item with NBT:

```json
{
  "id": "modpack_first_custom_potion",
  "triggerType": "ITEM_ACQUIRED",
  "trigger": {
    "item": "minecraft:potion",
    "count": 1,
    "nbt": "{Potion:\"minecraft:strong_healing\"}"
  },
  "title": "item_get.modpack.custom_potion.title",
  "subtitle": "",
  "description": "item_get.modpack.custom_potion.description",
  "icon": "minecraft:potion",
  "displayStyle": "SIDE",
  "sound": "item_get:item_acquired_soft",
  "pauseSingleplayer": false,
  "enabled": true,
  "triggerRevision": 1
}
```
