#!/usr/bin/env python3
import argparse
import json
import re
import sys
from pathlib import Path

TRIGGER_KEYS = {
    "ITEM_ACQUIRED": "item",
    "ENTITY_KILLED": "entity",
    "HEALTH_AT": "value",
    "HUNGER_AT": "value",
    "EFFECT_GAINED": "effect",
    "WEATHER_IS": "weather",
    "TIME_IS": "time",
    "ENTER_BIOME": "biome",
    "ENTER_STRUCTURE": "structure",
    "DIMENSION_CHANGED": "dimension",
    "DEATH_BY": "death",
    "ADVANCEMENT_DONE": "advancement",
    "OBSERVE_BLOCK": "block",
    "OBSERVE_ENTITY": "entity",
    "HOVER_ITEM": "item",
    "MANUAL": "manual",
}

ID_RE = re.compile(r"^[a-z0-9_./:-]+$")


def fail(message):
    print(f"ERROR: {message}")
    return 1


def warn(warnings, message):
    warnings.append(f"WARN: {message}")


def validate_rule(rule, index, seen, warnings):
    errors = []
    if not isinstance(rule, dict):
        return [f"rule[{index}] is not an object"]

    rule_id = str(rule.get("id", "")).strip()
    if not rule_id:
        errors.append(f"rule[{index}] has no id")
    elif rule_id in seen:
        errors.append(f"duplicate rule id: {rule_id}")
    else:
        seen.add(rule_id)
        if not ID_RE.match(rule_id):
            warn(warnings, f"{rule_id}: id contains unusual characters")

    trigger_type = str(rule.get("triggerType", "ITEM_ACQUIRED")).strip()
    if trigger_type not in TRIGGER_KEYS:
        errors.append(f"{rule_id or index}: unknown triggerType {trigger_type}")

    trigger = rule.get("trigger")
    if not isinstance(trigger, dict):
        errors.append(f"{rule_id or index}: trigger must be an object")
        trigger = {}

    key = TRIGGER_KEYS.get(trigger_type)
    if key and key not in trigger:
        errors.append(f"{rule_id or index}: triggerType {trigger_type} needs trigger.{key}")

    if trigger_type in {"ITEM_ACQUIRED", "ENTITY_KILLED", "OBSERVE_BLOCK", "OBSERVE_ENTITY", "HOVER_ITEM"}:
        count = trigger.get("count", 1)
        if not isinstance(count, int) or count < 1:
            warn(warnings, f"{rule_id or index}: count should be a positive integer")

    if trigger_type == "WEATHER_IS" and trigger.get("weather") not in {"clear", "rain", "thunder"}:
        warn(warnings, f"{rule_id or index}: weather should be clear, rain, or thunder")
    if trigger_type == "TIME_IS" and trigger.get("time") not in {"day", "noon", "night", "midnight"}:
        warn(warnings, f"{rule_id or index}: time should be day, noon, night, or midnight")
    if trigger_type == "MANUAL" and ":" not in str(trigger.get("manual", "")):
        warn(warnings, f"{rule_id or index}: manual trigger ids should usually be namespaced")

    conditions = trigger.get("conditions")
    if conditions is not None:
        if not isinstance(conditions, list) or not conditions:
            errors.append(f"{rule_id or index}: trigger.conditions must be a non-empty array")
        else:
            logic = trigger.get("condition_logic", "AND")
            if logic not in {"AND", "OR"}:
                errors.append(f"{rule_id or index}: condition_logic must be AND or OR")
            for c_index, condition in enumerate(conditions):
                if not isinstance(condition, dict):
                    errors.append(f"{rule_id or index}: condition[{c_index}] is not an object")
                    continue
                c_type = condition.get("type")
                data = condition.get("data", {})
                c_key = TRIGGER_KEYS.get(c_type)
                if c_type not in TRIGGER_KEYS:
                    errors.append(f"{rule_id or index}: condition[{c_index}] has unknown type {c_type}")
                elif not isinstance(data, dict) or c_key not in data:
                    errors.append(f"{rule_id or index}: condition[{c_index}] needs data.{c_key}")

    if not rule.get("title"):
        warn(warnings, f"{rule_id or index}: title is empty")
    if "displayStyle" in rule and rule["displayStyle"] not in {"HORIZONTAL", "SIDE"}:
        warn(warnings, f"{rule_id or index}: displayStyle should be HORIZONTAL or SIDE")
    if "triggerRevision" in rule and (not isinstance(rule["triggerRevision"], int) or rule["triggerRevision"] < 1):
        warn(warnings, f"{rule_id or index}: triggerRevision should be a positive integer")

    return errors


def main():
    parser = argparse.ArgumentParser(description="Validate and optionally format Item Get! rules.json")
    parser.add_argument("path", type=Path)
    parser.add_argument("--write", action="store_true", help="write formatted JSON back to the file")
    args = parser.parse_args()

    if not args.path.exists():
        return fail(f"file not found: {args.path}")

    try:
        rules = json.loads(args.path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        return fail(f"invalid JSON: {exc}")

    if not isinstance(rules, list):
        return fail("rules.json must be a JSON array")

    seen = set()
    warnings = []
    errors = []
    for index, rule in enumerate(rules):
        errors.extend(validate_rule(rule, index, seen, warnings))

    for message in warnings:
        print(message)
    for message in errors:
        print(f"ERROR: {message}")

    if errors:
        return 1

    if args.write:
        args.path.write_text(json.dumps(rules, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"OK: {len(rules)} Item Get! rule(s) validated")
    return 0


if __name__ == "__main__":
    sys.exit(main())
